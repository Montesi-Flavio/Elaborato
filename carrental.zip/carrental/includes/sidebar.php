<div class="profile_nav">
          <ul>
              <li><a href="?page=profile">Profile Settings</a></li>
              <li><a href="?page=update-password">Update Password</a></li>
              <li><a href="?page=my-booking">My Booking</a></li>
              <li><a href="?page=post-testimonial">Post a Testimonial</a></li>
              <li><a href="?page=my-testimonials">My Testimonials</a></li>
              <li><a href="?page=registration_car"> Register Car</a></li>
          </ul>
        </div>
      </div>