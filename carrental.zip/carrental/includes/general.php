<?php
    const ROOT_URL = 'http://localhost:63342/elaborato2.0';
    const ROOT_PATH = 'C:\\Users\flavi\Desktop\elaborato2.0\carrental\\';

    const DB_HOST = 'localhost';
    const DB_USERNAME = 'root';
    const DB_PASSWORD = '';
    const DB_NAME = 'elaborato';